/* [General] */

// Width of the block, in studs
block_width = 2;

// Length of the block, in studs
block_length = 4;

// Height of the block: 1/3 is a plate, 1 a brick
block_height_ratio = 1; // [.33333333333:1/3, .5:1/2, 1:1, 2:2]

// What type of block should this be?
block_type = "brick"; // [brick:Brick, tile:Tile]

block(width=block_width, length=block_length, height=block_height_ratio, type=block_type);

module block(width=1, length=2, height=1, type="brick") {
    cube([width * 8 - 0.2, length * 8 - 0.2, height * 9.6]);
    if (type == "brick")
        for (x = [0:width - 1], y = [0:length - 1])
            translate([x * 8 + 4, y * 8 + 4, height * 9.6]) cylinder(d=4.8, h=1.8, $fn=24);
}
