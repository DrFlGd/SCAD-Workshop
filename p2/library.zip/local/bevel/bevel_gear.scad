include <BOSL2/std.scad>
include <BOSL2/gears.scad>

// Number of teeth
teeth = 20; // [8:60]
// Tooth size (module)
mod = 2; // [0.5:0.5:5]

bevel_gear(mod=mod, teeth=teeth, mate_teeth=teeth, face_width=10);
