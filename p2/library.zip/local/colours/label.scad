// Label width
width = 20; // [10:40]
color("red") cube([width, 10, 2]);
color("white") translate([2, 2, 2]) cube([5, 5, 1]);
translate([width + 10, 0, 0]) cylinder(h = 5, r = 4);
