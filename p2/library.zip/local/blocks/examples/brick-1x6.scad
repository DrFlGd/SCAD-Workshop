use <../blocks.scad>;

block(w = 1, l = 6);
