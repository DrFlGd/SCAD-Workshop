// Plate size
size = 5; // [1:10]
use <blocks.scad>
block(size, size);
