module block(w = 1, l = 2) { cube([w * 8, l * 8, 9.6]); }
