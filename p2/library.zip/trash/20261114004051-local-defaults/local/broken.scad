size = 10;
assert(size < 5, "size must be under 5");
cube(size);
