// width in grid units
units = 1.5;
// height
height = 2.5; // [0:1:10]
cube([units * 42, 42, height]);
