SCAD Workshop library

This folder is a library for the SCAD Workshop desktop app: projects you added,
your own projects, saved settings and all your edits. Move it, copy it, sync it
or keep it in git, then use "Open library..." in the app to use it anywhere.

Library format 2 (SCAD Workshop 0.4.22 on). Each JSON file the app writes says
its "format"; a file with a higher number than the app knows was made by a
newer version, and the app reads it without writing over it. Library settings >
Check library lists anything that isn't as the app keeps it. The full
description: docs/LIBRARY_FORMAT.md in the app's source code.

  library.json    name, favourites, categories and library-wide settings
  sources/        one folder per project (below)
  local/          your own projects: put .scad or model files in a folder here
  recipes/        saved settings, with any code edits (a recipe, below)
  collections/    lists of parts and models with quantities and how many are
                  printed: collections/<id>/collection.json. Entries refer to
                  items by id (part:<project>/<part>, gen:<project>/<model>), not
                  copies; a model's entry keeps its settings and the fingerprint
                  of the files it used, as a recipe does
  icons/          pictures you chose for categories
  thumbs/         thumbnails of components (rebuildable)
  trash/          deleted projects, until you empty the trash
  backups/        JSON files as they were before the app upgraded them to a
                  newer format, as ZIPs (delete them when you like)

Inside sources/<project>/:
  source.json     where it came from and its versions; "version" is the one in
                  use. origin.type says where from: github (checked for updates),
                  zip, folder (copied in), linked (a folder elsewhere, below),
                  local (local/<name>/), app (a starter project from an earlier
                  app) or pinned (your pinned components).
                  origin.site names the model's page on a site (Printables) and
                  the PDF of that page among its files. "detected" is what was
                  read from the files and that PDF; your edits win over it
  metadata.json   your edits: names, categories, licenses, forms, your notes
                  ("my_notes"), parts made into one and files kept apart
                  ("apart"), projects merged into it, and what its folder of
                  examples should be. A picture you chose is its "icon":
                  file:<path> (one of its files) or picture:<name> (below);
                  content you added is listed under "attachments"
  pictures/       pictures you added for it (keep)
  attachments/    files you added to it: guides, videos, photos (keep)
  files/<version>/   the project's files exactly as they came, never changed. It
                  can hold several versions: on the project's page, Versions >
                  Remove versions not in use deletes the others
  derived/        what the app found when it read them (rebuildable)
  generated/      copies made so typed-in values become settings (rebuildable)
  docs/           the README as HTML, PDFs (rebuildable)
  thumbs/         pictures of its models and parts (rebuildable)
  examples/<fingerprint>/   parts made from a folder of examples, kept by the
                  files each example uses (rebuildable)
  previews/       models the app made for its parts (rebuildable)
  checks.json     whether each model renders at its defaults (rebuildable)
  workshop.json   what the app read the project as: its models and their
                  names and forms. It reports; it doesn't decide (rebuildable)
  description.json   the app's description of a project it knows from GitHub (a
                  starter project from an earlier app, Gridfinity Rebuilt...):
                  names and forms for the files it lists, and the files it leaves
                  out; any other file that draws something is a model too. Used
                  when the project has no workshop.json of its own. Keep it

Your own projects (local/<name>/) are read where they are: their sources/ folder
has no files/. Linked projects (origin "linked") are read from their own folder
outside the library: they don't move with it and aren't in its backups.
sources/pinned/pins/ holds the components you pinned as models: keep it, it
isn't rebuildable.

local/Made parts/<model>/ holds the parts you made from models (Save as part,
Batch generate), in a folder per model ("<model> (<project>)" when two models
share a name), as .stl or .3mf (the format chosen beside Download). Beside each
part, <name>.recipe.json says how it was made. Saved settings (recipes/) and
made parts' recipes have one shape: the model, its project and the project's
version, the fingerprint of the files the model used, the changed settings and
code edits, the file type ("output": stl or 3mf) and when it was made.
Make again and Open with these settings read it: keep it, it isn't rebuildable.

Rebuildable folders can be deleted: the app makes them again.
The app's render cache and search index are kept on each computer, not here.
