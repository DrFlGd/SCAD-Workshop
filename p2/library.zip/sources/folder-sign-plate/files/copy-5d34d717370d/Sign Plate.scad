width = 80; // [20:200]
height = 30; // [10:100]
difference() { square([width, height]); for (x = [6, width - 6]) translate([x, height / 2]) circle(d = 4, $fn = 32); }
