// Made by SCAD Workshop from examples/plate.scad: the values typed into its module calls are settings
// here, so the form can change them. The original file is unchanged.

use <../brick.scad>;

/* [Block] */
// Width of the block, in studs
width = 2;
// Length of the block, in studs
length = 4;
// Height of the block: 1/3 is a plate, 1 a brick
height = .33333333333; // [.33333333333:1/3, .5:1/2, 1:1, 2:2]
// What type of block should this be?
type = "tile"; // [brick:Brick, tile:Tile]

/* [Hidden] */

block(width=width, length=length, height=height, type=type);
