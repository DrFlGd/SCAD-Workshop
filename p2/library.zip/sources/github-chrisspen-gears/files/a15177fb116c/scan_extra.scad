size = 3; // [1:10]
cube(size);
