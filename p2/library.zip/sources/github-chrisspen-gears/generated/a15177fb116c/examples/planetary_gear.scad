// Made by SCAD Workshop from examples/planetary_gear.scad: the values typed into its module calls are settings
// here, so the form can change them. The original file is unchanged.

include <../gears.scad>

/* [Planetary gear 1] */
// Height of the Tooth Tip over the Partial Cone
modul = 1;
// Number of Teeth of the Sun Gear
sun_teeth = 16;
// Number of Teeth of a Planet Gear
planet_teeth = 9;
// Number of Planet Gears. If null, the Function will calculate the Minimum Number
number_planets = 5;
// tooth_width
width = 5;
// Width of the Rim from the Root Circle
rim_width = 3;
// Diameter of the Center Hole
bore = 4;
// Pressure Angle, Standard = 20° according to DIN 867. Should not exceed 45°.
pressure_angle = 20;
// Helix Angle to the Axis of Rotation, Standard = 0° (Spur Teeth)
helix_angle = 30;
// Components assembled for Construction or separated for 3D-Printing
together_built = true;
// Create holes for Material-/Weight-Saving or Surface Enhancements where Geometry allows
optimized = true;

/* [Planetary gear 2] */
// Height of the Tooth Tip over the Partial Cone
modul_2 = 2;
// Number of Teeth of the Sun Gear
sun_teeth_2 = 16;
// Number of Teeth of a Planet Gear
planet_teeth_2 = 9;
// Number of Planet Gears. If null, the Function will calculate the Minimum Number
number_planets_2 = 5;
// tooth_width
width_2 = 5;
// Width of the Rim from the Root Circle
rim_width_2 = 3;
// Diameter of the Center Hole
bore_2 = 4;
// Pressure Angle, Standard = 20° according to DIN 867. Should not exceed 45°.
pressure_angle_2 = 20;
// Helix Angle to the Axis of Rotation, Standard = 0° (Spur Teeth)
helix_angle_2 = 30;
// Components assembled for Construction or separated for 3D-Printing
together_built_2 = true;
// Create holes for Material-/Weight-Saving or Surface Enhancements where Geometry allows
optimized_2 = false;

/* [Hidden] */

planetary_gear(modul=modul, sun_teeth=sun_teeth, planet_teeth=planet_teeth, number_planets=number_planets, width=width, rim_width=rim_width, bore=bore, pressure_angle=pressure_angle, helix_angle=helix_angle, together_built=together_built, optimized=optimized);
translate([80, 0, 0])
planetary_gear(modul=modul_2, sun_teeth=sun_teeth_2, planet_teeth=planet_teeth_2, number_planets=number_planets_2, width=width_2, rim_width=rim_width_2, bore=bore_2, pressure_angle=pressure_angle_2, helix_angle=helix_angle_2, together_built=together_built_2, optimized=optimized_2);
