// Made by SCAD Workshop from examples/worm_gear.scad: the values typed into its module calls are settings
// here, so the form can change them. The original file is unchanged.

include <../gears.scad>

/* [Worm gear] */
// Height of the screw head above the partial cylinder or the tooth head above the pitch circle
modul = 1;
// Number of wheel teeth
tooth_number = 30;
// Number of gears (teeth) of the screw
thread_starts = 2;
// tooth_width
width = 8;
// Length of the Worm
length = 20;
// Diameter of the Center Hole of the Worm
worm_bore = 4;
// Diameter of the Center Hole of the Spur Gear
gear_bore = 4;
// Pressure Angle, Standard = 20° according to DIN 867. Should not exceed 45°.
pressure_angle = 20;
// Pitch angle of the worm corresponds to 90 ° bevel angle. Positive slope angle = clockwise.
lead_angle = 10;
// Holes for material / weight savings
optimized = 1;
// Components assembled for construction or apart for 3D printing
together_built = 1;
show_spur = 1;
show_worm = 1;

/* [Hidden] */

worm_gear(modul=modul, tooth_number=tooth_number, thread_starts=thread_starts, width=width, length=length, worm_bore=worm_bore, gear_bore=gear_bore, pressure_angle=pressure_angle, lead_angle=lead_angle, optimized=optimized, together_built=together_built, show_spur=show_spur, show_worm=show_worm);
