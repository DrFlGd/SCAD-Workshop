// Made by SCAD Workshop from examples/rack_and_pinion.scad: the values typed into its module calls are settings
// here, so the form can change them. The original file is unchanged.

include <../gears.scad>

/* [Rack and pinion] */
// Height of the Tooth Tip beyond the Pitch Circle
modul = 1;
// Length of the Rack
rack_length = 50;
// Number of Gear Teeth
gear_teeth = 30;
// Height of the Rack to the Pitch Line
rack_height = 4;
// Diameter of the Center Hole of the Spur Gear
gear_bore = 4;
// Width of a Tooth
width = 5;
// Pressure Angle, Standard = 20° according to DIN 867. Should not exceed 45°.
pressure_angle = 20;
// Helix Angle to the Axis of Rotation, Standard = 0° (Spur Teeth)
helix_angle = 0;
together_built = true;
optimized = true;

/* [Hidden] */

rack_and_pinion(modul=modul, rack_length=rack_length, gear_teeth=gear_teeth, rack_height=rack_height, gear_bore=gear_bore, width=width, pressure_angle=pressure_angle, helix_angle=helix_angle, together_built=together_built, optimized=optimized);
