// Made by SCAD Workshop from examples/worm.scad: the values typed into its module calls are settings
// here, so the form can change them. The original file is unchanged.

include <../gears.scad>

/* [Worm] */
// Height of the Screw Head over the Part Cylinder
modul = 1;
// Number of Starts (Threads) of the Worm
thread_starts = 2;
// Length of the Worm
length = 15;
// Diameter of the Center Hole
bore = 4;
// Pressure Angle, Standard = 20° according to DIN 867. Should not exceed 45°.
pressure_angle = 20;
// Lead Angle of the Worm, corresponds to 90° minus Helix Angle. Positive Lead Angle = clockwise.
lead_angle = 10;
// Components assembled for Construction or separated for 3D-Printing
together_built = true;

/* [Hidden] */

worm(modul=modul, thread_starts=thread_starts, length=length, bore=bore, pressure_angle=pressure_angle, lead_angle=lead_angle, together_built=together_built);
