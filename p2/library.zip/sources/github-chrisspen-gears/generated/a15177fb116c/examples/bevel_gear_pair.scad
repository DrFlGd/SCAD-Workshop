// Made by SCAD Workshop from examples/bevel_gear_pair.scad: the values typed into its module calls are settings
// here, so the form can change them. The original file is unchanged.

include <../gears.scad>

/* [Bevel gear pair] */
// Height of the Tooth Tip over the Partial Cone; Specification for the Outside of the Cone
modul = 1;
// Number of Gear Teeth on the Gear
gear_teeth = 30;
// Number of Gear Teeth on the Pinion
pinion_teeth = 11;
// Angle between the Axles of the Gear and Pinion
axis_angle = 100;
// Width of the Teeth from the Outside toward the apex of the Cone
tooth_width = 5;
// Diameter of the Center Hole of the Gear
gear_bore = 4;
// Diameter of the Center Bore of the Gear
pinion_bore = 4;
// Pressure Angle, Standard = 20° according to DIN 867. Should not exceed 45°.
pressure_angle = 20;
// Helix Angle, Standard = 0°
helix_angle = 20;
// Components assembled for Construction or separated for 3D-Printing
together_built = true;

/* [Hidden] */

bevel_gear_pair(modul=modul, gear_teeth=gear_teeth, pinion_teeth=pinion_teeth, axis_angle=axis_angle, tooth_width=tooth_width, gear_bore=gear_bore, pinion_bore=pinion_bore, pressure_angle=pressure_angle, helix_angle=helix_angle, together_built=together_built);
