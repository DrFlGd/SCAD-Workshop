// Made by SCAD Workshop from examples/ring.scad: the values typed into its module calls are settings
// here, so the form can change them. The original file is unchanged.

include <../gears.scad>

/* [Planetary gear] */
// Height of the Tooth Tip over the Partial Cone
modul = 1;
// Number of Teeth of the Sun Gear
sun_teeth = 30;
// Number of Teeth of a Planet Gear
planet_teeth = 60;
// Number of Planet Gears. If null, the Function will calculate the Minimum Number
number_planets = 3;
// tooth_width
width = 5;
// Width of the Rim from the Root Circle
rim_width = 3;
// Diameter of the Center Hole
bore = 3;
// Pressure Angle, Standard = 20° according to DIN 867. Should not exceed 45°.
pressure_angle = 20;

/* [Hidden] */

planetary_gear(modul=modul, sun_teeth=sun_teeth, planet_teeth=planet_teeth, number_planets=number_planets, width=width, rim_width=rim_width, bore=bore, pressure_angle=pressure_angle);
