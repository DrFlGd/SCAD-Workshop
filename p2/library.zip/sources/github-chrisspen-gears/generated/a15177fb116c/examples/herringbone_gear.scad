// Made by SCAD Workshop from examples/herringbone_gear.scad: the values typed into its module calls are settings
// here, so the form can change them. The original file is unchanged.

include <../gears.scad>

/* [Herringbone gear] */
// Height of the Tooth Tip beyond the Pitch Circle
modul = 1;
// Number of Gear Teeth
tooth_number = 30;
// tooth_width
width = 5;
// Diameter of the Center Hole
bore = 4;
// Pressure Angle, Standard = 20° according to DIN 867. Should not exceed 45°.
pressure_angle = 20;
// Helix Angle to the Axis of Rotation, Standard = 0° (Spur Teeth)
helix_angle = 30;
// Holes for Material-/Weight-Saving
optimized = true;

/* [Hidden] */

herringbone_gear(modul=modul, tooth_number=tooth_number, width=width, bore=bore, pressure_angle=pressure_angle, helix_angle=helix_angle, optimized=optimized);
