// Made by SCAD Workshop from examples/ring_gear.scad: the values typed into its module calls are settings
// here, so the form can change them. The original file is unchanged.

include <../gears.scad>

/* [Ring gear] */
// Height of the Tooth Tip beyond the Pitch Circle
modul = 1;
// Number of Gear Teeth
tooth_number = 30;
// tooth_width
width = 5;
// Width of the Rim from the Root Circle bore = Diameter of the Center Hole
rim_width = 3;
// Pressure Angle, Standard = 20° according to DIN 867. Should not exceed 45°.
pressure_angle = 20;
// Helix Angle to the Axis of Rotation, Standard = 0° (Spur Teeth)
helix_angle = 20;

/* [Hidden] */

ring_gear(modul=modul, tooth_number=tooth_number, width=width, rim_width=rim_width, pressure_angle=pressure_angle, helix_angle=helix_angle);
