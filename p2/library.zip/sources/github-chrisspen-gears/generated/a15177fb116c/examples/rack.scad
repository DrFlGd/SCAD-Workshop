// Made by SCAD Workshop from examples/rack.scad: the values typed into its module calls are settings
// here, so the form can change them. The original file is unchanged.

include <../gears.scad>

/* [Rack] */
// Height of the Tooth Tip above the Rolling LIne
modul = 1;
// Length of the Rack
length = 60;
// Height of the Rack to the Pitch Line
height = 5;
// Width of a Tooth
width = 20;
// Pressure Angle, Standard = 20° according to DIN 867. Should not exceed 45°.
pressure_angle = 20;
// Helix Angle of the Rack Transverse Axis; 0° = Spur Teeth
helix_angle = 0;

/* [Hidden] */

rotate([90,0,0])
rack(modul=modul, length=length, height=height, width=width, pressure_angle=pressure_angle, helix_angle=helix_angle);
