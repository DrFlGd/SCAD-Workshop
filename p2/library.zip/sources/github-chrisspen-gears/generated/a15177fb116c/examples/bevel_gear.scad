// Made by SCAD Workshop from examples/bevel_gear.scad: the values typed into its module calls are settings
// here, so the form can change them. The original file is unchanged.

include <../gears.scad>

/* [Bevel gear] */
// Height of the Tooth Tip over the Partial Cone; Specification for the Outside of the Cone
modul = 1;
// Number of Gear Teeth
tooth_number = 30;
// (Half)angle of the Cone on which the other Ring Gear rolls
partial_cone_angle = 45;
// Width of the Teeth from the Outside toward the apex of the Cone
tooth_width = 5;
// Diameter of the Center Hole
bore = 4;
// Pressure Angle, Standard = 20° according to DIN 867. Should not exceed 45°.
pressure_angle = 20;
// Helix Angle, Standard = 0°
helix_angle = 20;

/* [Hidden] */

bevel_gear(modul=modul, tooth_number=tooth_number, partial_cone_angle=partial_cone_angle, tooth_width=tooth_width, bore=bore, pressure_angle=pressure_angle, helix_angle=helix_angle);
