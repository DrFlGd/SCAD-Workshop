// Made by SCAD Workshop from examples/mountable_rack.scad: the values typed into its module calls are settings
// here, so the form can change them. The original file is unchanged.

include <../gears.scad>

/* [Mountable rack] */
// Height of the Tooth Tip above the Rolling LIne
modul = 1;
// Length of the Rack
length = 60;
// Height of the Rack to the Pitch Line
height = 5;
// Width of a Tooth
width = 20;
// Pressure Angle, Standard = 20° according to DIN 867. Should not exceed 45°.
pressure_angle = 20;
// Helix Angle of the Rack Transverse Axis; 0° = Spur Teeth
helix_angle = 0;
// Metric standard profile for fastners (ISO machine screws), M4 = 4, M6 = 6 etc.
profile = 3;
// Style of fastner to accomodate. PH = Pan Head, C = Countersunk, RC = Raised Countersunk, CS = Cap Screw, CSS = Countersunk Socket Screw.
head = "PH";
// Total number of fastners.
fastners = 3;

/* [Hidden] */

rotate([90,0,0])
mountable_rack(modul=modul, length=length, height=height, width=width, pressure_angle=pressure_angle, helix_angle=helix_angle, profile=profile, head=head, fastners=fastners);
