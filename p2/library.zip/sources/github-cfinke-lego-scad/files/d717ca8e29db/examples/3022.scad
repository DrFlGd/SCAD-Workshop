use <../LEGO.scad>;

block(
    width=2,
    length=2,
    height=1/3
);