use <../LEGO.scad>;

block(
    width=1,
    length=2,
    height=2,
    type="slope"
);