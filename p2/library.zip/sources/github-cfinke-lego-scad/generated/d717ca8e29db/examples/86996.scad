// Made by SCAD Workshop from examples/86996.scad: the values typed into its module calls are settings
// here, so the form can change them. The original file is unchanged.

use <../LEGO.scad>;

/* [Block] */
// Width of the block, in studs
width = 1;
// Length of the block, in studs
length = 1;
// Height of the block. A ratio of "1" is a standard LEGO brick height; a ratio of "1/3" is a standard LEGO plate height; "1/2" is a standard DUPLO plate.
height = 0.6666666666666666; // [.33333333333:1/3, .5:1/2, 0.6666666666666666:2/3, 1:1, 1.5:1 1/2, 2:2, 3:3, 4:4, 5:5, 6:6, 7:7, 8:8, 9:9, 10:10]
// What stud type do you want?
stud_type = "hollow"; // [solid:Solid, hollow:Hollow, open:Open]

/* [Hidden] */

block(width=width, length=length, height=height, stud_type=stud_type);
