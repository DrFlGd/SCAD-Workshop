// Made by SCAD Workshop from examples/54383.scad: the values typed into its module calls are settings
// here, so the form can change them. The original file is unchanged.

use <../LEGO.scad>;

/* [Block] */
// Width of the block, in studs
width = 3;
// Length of the block, in studs
length = 6;
// Height of the block. A ratio of "1" is a standard LEGO brick height; a ratio of "1/3" is a standard LEGO plate height; "1/2" is a standard DUPLO plate.
height = .33333333333; // [.33333333333:1/3, .5:1/2, 1:1, 1.5:1 1/2, 2:2, 3:3, 4:4, 5:5, 6:6, 7:7, 8:8, 9:9, 10:10]
// What type of block should this be? For type-specific options, see the "Wings," "Slopes," "Curves", and "Baseplates" tabs.
type = "wing"; // [brick:Brick, tile:Tile, wing:Wing, slope:Slope, curve:Curve, baseplate:Baseplate, round:Round, round-tile:Round Tile]
// What type of wing? Full is suitable for the front of a plane, left/right are for the left/right of a plane.
wing_type = "right"; // [full:Full, left:Left, right:Right]
// On the wide end of the wing, how many rows of studs should be placed before the first shorter row of studs?
wing_base_length = 0;
// The number of studs across the narrower end of the wing. `width` is the equivalent for the wide end of the wing.
wing_end_width = 1;
stud_notches = true;

/* [Hidden] */

block(width=width, length=length, height=height, type=type, wing_type=wing_type, wing_base_length=wing_base_length, wing_end_width=wing_end_width, stud_notches=stud_notches);
