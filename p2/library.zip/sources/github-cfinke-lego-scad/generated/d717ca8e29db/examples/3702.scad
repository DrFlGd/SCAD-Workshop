// Made by SCAD Workshop from examples/3702.scad: the values typed into its module calls are settings
// here, so the form can change them. The original file is unchanged.

use <../LEGO.scad>;

/* [Block] */
// Width of the block, in studs
width = 1;
// Length of the block, in studs
length = 8;
// Should the block include horizontal Technic axle holes? (See vertical_axle_hole_shape for shape)
horizontal_axle_holes = true;
// Should the block include horizontal Technic cross-shaped axle holes?
horizontal_axle_hole_shape = "round"; // [round:Round, cross:Cross]

/* [Hidden] */

block(width=width, length=length, horizontal_axle_holes=horizontal_axle_holes, horizontal_axle_hole_shape=horizontal_axle_hole_shape);
