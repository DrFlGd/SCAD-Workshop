// Made by SCAD Workshop from examples/3010.scad: the values typed into its module calls are settings
// here, so the form can change them. The original file is unchanged.

use <../LEGO.scad>;

/* [Block] */
// Width of the block, in studs
width = 1;
// Length of the block, in studs
length = 4;

/* [Hidden] */

block(width=width, length=length);
