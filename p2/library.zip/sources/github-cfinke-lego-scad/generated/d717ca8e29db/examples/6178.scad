// Made by SCAD Workshop from examples/6178.scad: the values typed into its module calls are settings
// here, so the form can change them. The original file is unchanged.

use <../LEGO.scad>;

/* [Block] */
// Width of the block, in studs
width = 6;
// Length of the block, in studs
length = 12;
// Height of the block. A ratio of "1" is a standard LEGO brick height; a ratio of "1/3" is a standard LEGO plate height; "1/2" is a standard DUPLO plate.
height = .33333333333; // [.33333333333:1/3, .5:1/2, 1:1, 1.5:1 1/2, 2:2, 3:3, 4:4, 5:5, 6:6, 7:7, 8:8, 9:9, 10:10]
// A single string representing rows of stud position, automatically wrapping to subsequent rows. An asterisk means "put a stud there"; any other character means "omit the stud there". Newlines will be ignored.
stud_matrix_string = "************
*__________*
*__________*
*__________*
*__________*
*__________*
";
// How many columns per row in the stud matrix string? Not directly related to the size of the baseplate.
stud_matrix_columns = 12;

/* [Hidden] */

block(width=width, length=length, height=height, stud_matrix_string=stud_matrix_string, stud_matrix_columns=stud_matrix_columns);
