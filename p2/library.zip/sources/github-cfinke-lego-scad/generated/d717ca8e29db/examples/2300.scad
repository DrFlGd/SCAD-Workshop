// Made by SCAD Workshop from examples/2300.scad: the values typed into its module calls are settings
// here, so the form can change them. The original file is unchanged.

use <../LEGO.scad>;

/* [Block] */
// Width of the block, in studs
width = 2;
// Length of the block, in studs
length = 6;
// What brand of block should this be? LEGO for regular LEGO bricks, Duplo for the toddler-focused larger bricks.
brand = "duplo"; // [lego:LEGO, duplo:DUPLO]
// What stud type do you want?
stud_type = "hollow"; // [solid:Solid, hollow:Hollow, open:Open]

/* [Hidden] */

block(width=width, length=length, brand=brand, stud_type=stud_type);
