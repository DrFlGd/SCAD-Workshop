// Made by SCAD Workshop from examples/35114.scad: the values typed into its module calls are settings
// here, so the form can change them. The original file is unchanged.

use <../LEGO.scad>;

/* [Block] */
// Width of the block, in studs
width = 2;
// Length of the block, in studs
length = 3;
// What brand of block should this be? LEGO for regular LEGO bricks, Duplo for the toddler-focused larger bricks.
brand = "duplo"; // [lego:LEGO, duplo:DUPLO]
// What type of block should this be? For type-specific options, see the "Wings," "Slopes," "Curves", and "Baseplates" tabs.
type = "slope"; // [brick:Brick, tile:Tile, wing:Wing, slope:Slope, curve:Curve, baseplate:Baseplate, round:Round, round-tile:Round Tile]

/* [Hidden] */

block(width=width, length=length, brand=brand, type=type);
