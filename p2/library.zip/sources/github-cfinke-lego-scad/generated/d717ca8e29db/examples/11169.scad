// Made by SCAD Workshop from examples/11169.scad: the values typed into its module calls are settings
// here, so the form can change them. The original file is unchanged.

use <../LEGO.scad>;

/* [Block] */
// Width of the block, in studs
width = 2;
// Length of the block, in studs
length = 2;
// Height of the block. A ratio of "1" is a standard LEGO brick height; a ratio of "1/3" is a standard LEGO plate height; "1/2" is a standard DUPLO plate.
height = 1.5; // [.33333333333:1/3, .5:1/2, 1:1, 1.5:1 1/2, 2:2, 3:3, 4:4, 5:5, 6:6, 7:7, 8:8, 9:9, 10:10]
// What brand of block should this be? LEGO for regular LEGO bricks, Duplo for the toddler-focused larger bricks.
brand = "duplo"; // [lego:LEGO, duplo:DUPLO]
// What type of block should this be? For type-specific options, see the "Wings," "Slopes," "Curves", and "Baseplates" tabs.
type = "curve"; // [brick:Brick, tile:Tile, wing:Wing, slope:Slope, curve:Curve, baseplate:Baseplate, round:Round, round-tile:Round Tile]
// What stud type do you want?
stud_type = "hollow"; // [solid:Solid, hollow:Hollow, open:Open]
// How many rows of studs should be left before the curve?
curve_stud_rows = 2;
// Should the curve be convex or concave?
curve_type = "concave"; // [concave:Concave, convex:Convex]

/* [Hidden] */

block(width=width, length=length, height=height, brand=brand, type=type, stud_type=stud_type, curve_stud_rows=curve_stud_rows, curve_type=curve_type);
