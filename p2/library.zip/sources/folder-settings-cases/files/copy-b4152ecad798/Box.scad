style = "round";
label = "Box";
if (style == "square") cube(10);
else if (style == "hex") cylinder(d = 10, h = 10, $fn = 6);
else cylinder(d = 10, h = 10);
