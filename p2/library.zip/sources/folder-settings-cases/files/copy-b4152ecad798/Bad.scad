size = 0; // [0:50]
assert(size > 0, "size must be over 0");
cube(size);
