// Peg length
length = 20; // [5:1:60]
cylinder(d=6, h=length, $fn=24);
