// Hook depth
depth = 12; // [4:1:30]
cube([6, depth, 6]);
